(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["mycards-mycards-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/mycards/mycards.page.html":
/*!********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/mycards/mycards.page.html ***!
  \********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n      <!-- <ion-button (click)=\"onOpenMenu()\">\n        Open\n      </ion-button> -->\n    </ion-buttons>\n    <ion-title>My Cards</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <ion-grid *ngIf=\"isLoading\">\n    <ion-row>\n      <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\" class=\"ion-text-center\">\n        <ion-spinner color=\"primary\"></ion-spinner>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid\n    *ngIf=\"!isLoading && (!relevantSavedcards || relevantSavedcards.length <= 0)\">\n    <ion-row>\n      <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\" class=\"ion-text-center\">\n        <p>No Visiting Cards received yet!</p>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid *ngIf=\"!isLoading && relevantSavedcards.length > 0\">\n    <ion-row>\n      <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\" class=\"ion-text-center\">\n        <ion-card>\n          <ion-card-header>\n            <ion-card-title>{{ relevantSavedcards[0].senderName }}</ion-card-title>\n            <ion-card-subtitle>{{ relevantSavedcards[0].senderContactNumber}} </ion-card-subtitle>\n          </ion-card-header>\n          <ion-img [src]=\"relevantSavedcards[0].senderCardImage\"></ion-img>\n          <ion-card-content>\n            <p>{{ relevantSavedcards[0].senderCompanyName }}</p>\n          </ion-card-content>\n        </ion-card>\n      </ion-col>\n    </ion-row>\n     <!-- <ion-row>\n      <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\" class=\"ion-text-center\">\n        <ion-virtual-scroll\n          [items]=\"listedLoadedSavedcards\"\n          approxItemHeight=\"70px\">\n          <ion-item\n            [routerLink]=\"['/', 'savedcards', 'tabs', 'mycards', savedcards.id]\"\n            detail\n            *virtualItem=\"let sendings\">\n            <ion-thumbnail slot=\"start\">\n              <ion-img [src]=\"sendings.senderCardImage\"></ion-img>\n            </ion-thumbnail>\n            <ion-label>\n              <h2>{{ sendings.senderName }}</h2>\n              <p>{{ sendings.senderContactNumber }}</p>\n              <p>{{ sendings.senderCompanyName }}</p>\n            </ion-label>\n          </ion-item>\n        </ion-virtual-scroll>\n      </ion-col>\n    </ion-row>  -->\n  </ion-grid>\n</ion-content>\n");

/***/ }),

/***/ "./src/app/savedcards/mycards/mycards.module.ts":
/*!******************************************************!*\
  !*** ./src/app/savedcards/mycards/mycards.module.ts ***!
  \******************************************************/
/*! exports provided: MycardsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MycardsPageModule", function() { return MycardsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _mycards_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./mycards.page */ "./src/app/savedcards/mycards/mycards.page.ts");







const routes = [
    {
        path: '',
        component: _mycards_page__WEBPACK_IMPORTED_MODULE_6__["MycardsPage"]
    }
];
let MycardsPageModule = class MycardsPageModule {
};
MycardsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_mycards_page__WEBPACK_IMPORTED_MODULE_6__["MycardsPage"]]
    })
], MycardsPageModule);



/***/ }),

/***/ "./src/app/savedcards/mycards/mycards.page.scss":
/*!******************************************************!*\
  !*** ./src/app/savedcards/mycards/mycards.page.scss ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NhdmVkY2FyZHMvbXljYXJkcy9teWNhcmRzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/savedcards/mycards/mycards.page.ts":
/*!****************************************************!*\
  !*** ./src/app/savedcards/mycards/mycards.page.ts ***!
  \****************************************************/
/*! exports provided: MycardsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MycardsPage", function() { return MycardsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _profile_profile_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../profile/profile.service */ "./src/app/savedcards/profile/profile.service.ts");




let MycardsPage = class MycardsPage {
    constructor(sendingService, menuCtrl) {
        this.sendingService = sendingService;
        this.menuCtrl = menuCtrl;
        // loadedSavedcards: Savedcard[];
        // listedLoadedSavedcards: Savedcard[];
        // relevantSavedcards: Savedcard[];
        // private savedcardsSub: Subscription;
        this.isLoading = false;
    }
    ngOnInit() {
        this.sendingSub = this.sendingService.sendings.subscribe(sendings => {
            this.loadedSavedcards = sendings;
            this.relevantSavedcards = this.loadedSavedcards;
            // this.listedLoadedSavedcards = this.relevantSavedcards.slice(1);
            this.listedLoadedSavedcards = this.relevantSavedcards;
        });
    }
    ionViewWillEnter() {
        this.isLoading = true;
        this.sendingService.fetchSavedcards().subscribe(() => {
            this.isLoading = false;
        });
    }
    onOpenMenu() {
        this.menuCtrl.toggle();
    }
    ngOnDestroy() {
        if (this.sendingSub) {
            this.sendingSub.unsubscribe();
        }
    }
};
MycardsPage.ctorParameters = () => [
    { type: _profile_profile_service__WEBPACK_IMPORTED_MODULE_3__["SendingService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["MenuController"] }
];
MycardsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-mycards',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./mycards.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/mycards/mycards.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./mycards.page.scss */ "./src/app/savedcards/mycards/mycards.page.scss")).default]
    })
], MycardsPage);



/***/ })

}]);
//# sourceMappingURL=mycards-mycards-module-es2015.js.map