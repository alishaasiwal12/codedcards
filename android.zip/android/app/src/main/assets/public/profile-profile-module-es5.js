function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/profile/profile.page.html":
  /*!********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/profile/profile.page.html ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSavedcardsProfileProfilePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>My Account</ion-title>\n    <ion-buttons slot=\"primary\">\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header> \n  \n\n<ion-content class=\"ion-padding\">\n  <ion-grid *ngIf=\"isLoading\">\n    <ion-row>\n      <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\" class=\"ion-text-center\">\n        <ion-spinner color=\"primary\"></ion-spinner>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid *ngIf=\"!isLoading && account == null\">\n    <ion-row>\n      <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\" class=\"ion-text-center\">\n        <p>Business Card not created! Please create one first!</p>\n        <ion-button color=\"primary\" routerLink=\"/savedcards/tabs/profile/userdetails\">\n          Create Business Card\n        </ion-button>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-grid *ngIf=\"!isLoading && account != null\">\n    <ion-row>\n      <ion-col size=\"12\" size-sm=\"8\" offset-sm=\"2\" class=\"ion-text-center\">\n        <ion-card>\n           <ion-card-header>\n            <ion-card-title>{{ account.name }}</ion-card-title>\n            <ion-card-subtitle>{{ account.contactnumber }}</ion-card-subtitle>\n          </ion-card-header> \n          <ion-img [src]=\"account.imageUrl\"></ion-img>\n          <ion-card-content>\n            <p>{{ account.companyname }}</p>\n          </ion-card-content>\n              <!-- <ion-row *ngIf=\"isAvailable\"> -->\n                <ion-row>\n                  <ion-col size-sm=\"6\" offset-sm=\"3\" class=\"ion-text-center\">\n                    <ion-button color=\"primary\" (click)=\"onShare()\">Send</ion-button>\n                  </ion-col>\n                </ion-row>\n         </ion-card>      \n\n         <!-- <ion-item-sliding #slidingItem>\n          <ion-item [account]=\"account\"></ion-item>\n          <ion-item-options side=\"end\">\n            <ion-item-option color=\"secondary\"\n              (click)=\"onEdit(account.id, slidingItem)\">\n              <ion-icon name=\"create\" slot=\"icon-only\"></ion-icon>\n            </ion-item-option>\n          </ion-item-options>\n        </ion-item-sliding> -->\n\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>    \n\n";
    /***/
  },

  /***/
  "./src/app/savedcards/profile/profile.module.ts":
  /*!******************************************************!*\
    !*** ./src/app/savedcards/profile/profile.module.ts ***!
    \******************************************************/

  /*! exports provided: ProfilePageModule */

  /***/
  function srcAppSavedcardsProfileProfileModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function () {
      return ProfilePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./profile.page */
    "./src/app/savedcards/profile/profile.page.ts");
    /* harmony import */


    var src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/shared/shared.module */
    "./src/app/shared/shared.module.ts");

    var routes = [{
      path: '',
      component: _profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]
    }];

    var ProfilePageModule = function ProfilePageModule() {
      _classCallCheck(this, ProfilePageModule);
    };

    ProfilePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes), src_app_shared_shared_module__WEBPACK_IMPORTED_MODULE_7__["SharedModule"]],
      declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]] // entryComponents: [SendcardPage]

    })], ProfilePageModule);
    /***/
  },

  /***/
  "./src/app/savedcards/profile/profile.page.scss":
  /*!******************************************************!*\
    !*** ./src/app/savedcards/profile/profile.page.scss ***!
    \******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSavedcardsProfileProfilePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NhdmVkY2FyZHMvcHJvZmlsZS9wcm9maWxlLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/savedcards/profile/profile.page.ts":
  /*!****************************************************!*\
    !*** ./src/app/savedcards/profile/profile.page.ts ***!
    \****************************************************/

  /*! exports provided: ProfilePage */

  /***/
  function srcAppSavedcardsProfileProfilePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ProfilePage", function () {
      return ProfilePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _savedcards_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../savedcards.service */
    "./src/app/savedcards/savedcards.service.ts");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../auth/auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var _profile_profile_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../profile/profile.service */
    "./src/app/savedcards/profile/profile.service.ts");
    /* harmony import */


    var _services_fcm_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../../services/fcm.service */
    "./src/app/services/fcm.service.ts");
    /* harmony import */


    var _services_ionic_toast_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../../services/ionic-toast.service */
    "./src/app/services/ionic-toast.service.ts");

    var ProfilePage = /*#__PURE__*/function () {
      function ProfilePage(ionicToastService, toastController, fcm, savedcardsService, sendingService, loadingCtrl, authService, alertCtrl, router) {
        _classCallCheck(this, ProfilePage);

        this.ionicToastService = ionicToastService;
        this.toastController = toastController;
        this.fcm = fcm;
        this.savedcardsService = savedcardsService;
        this.sendingService = sendingService;
        this.loadingCtrl = loadingCtrl;
        this.authService = authService;
        this.alertCtrl = alertCtrl;
        this.router = router;
        this.isAvailable = false;
        this.isExists = false;
        this.isLoading = false;
        this.TOPIC_NAME = 'homeTopic';
        this.isSubscribed = false;
      }

      _createClass(ProfilePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.isLoading = true;
          var fetchedUserEmail;
          this.authService.userEmail.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function (userEmail) {
            fetchedUserEmail = userEmail;
            return _this.savedcardsService.getMyAccount(fetchedUserEmail);
          })).subscribe(function (account) {
            _this.account = account; // this.isAvailable = account.userEmail !== fetchedUserEmail;

            _this.isLoading = false;
          });
        }
      }, {
        key: "onShare",
        value: function onShare() {
          var _this2 = this;

          this.alertCtrl.create({
            header: 'Send Your Card',
            inputs: [{
              name: 'ContactNumber',
              placeholder: 'Contact Number',
              type: 'number'
            }],
            buttons: [{
              text: 'Cancel',
              role: 'cancel',
              handler: function handler(data) {
                console.log('Cancel clicked');
              }
            }, {
              text: 'Send',
              handler: function handler(data) {
                _this2.onFindingReceiver(data.ContactNumber);
              }
            }]
          }).then(function (alertEl) {
            alertEl.present();
          });
        }
      }, {
        key: "onFindingReceiver",
        value: function onFindingReceiver(ContactNumber) {
          var _this3 = this;

          try {
            this.isLoading = true;
            var fetchedUserEmail;
            this.authService.userEmail.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["switchMap"])(function (userEmail) {
              fetchedUserEmail = userEmail;
              return _this3.savedcardsService.getReceiver(ContactNumber);
            })).subscribe(function (receiver) {
              _this3.receiver = receiver;

              _this3.onSending(_this3.receiver);

              _this3.isLoading = false;
            });
          } catch (e) {
            console.log("onSending:: ", e);
          }
        }
      }, {
        key: "onSending",
        value: function onSending(receiver) {
          var _this4 = this;

          try {
            if (receiver != null) {
              this.loadingCtrl.create({
                message: 'Sending...'
              }).then(function (loadingEl) {
                loadingEl.present();

                _this4.sendingService.addCard(_this4.account.name, _this4.account.contactnumber, _this4.account.companyname, _this4.account.imageUrl, receiver.userId, receiver.name, receiver.contactnumber, receiver.companyname).subscribe(function () {
                  loadingEl.dismiss();
                });
              });
              this.ionicToastService.sentCardToast();
              this.ionicToastService.HideToast();
            } else {
              // error => {
              //   this.alertCtrl
              //     .create({
              //       header: 'An error ocurred!',
              //       message: 'Receiver not Found, Check Contact Number',
              //       buttons: [
              //         {
              //           text: 'Okay',
              //           handler: () => {
              //             this.router.navigate(['/savedcards/tabs/profile']);
              //           }
              //         }
              //       ]
              //     })
              //     .then(alertEl => alertEl.present());
              // }
              this.fcm.topicSubscription(this.TOPIC_NAME); // this.fcm.topicUnsubscription(this.TOPIC_NAME);
            }
          } catch (e) {
            console.log("onSending:: ", e);
          }
        } // onEdit(userId: string, slidingItem: IonItemSliding) {
        //   slidingItem.close();
        //   this.router.navigate(['/', 'savedcards', 'tabs', 'profile', 'edit-user', userId]);
        //   console.log('Editing item', userId);
        // }

      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.SavedcardsSub) {
            this.SavedcardsSub.unsubscribe();
          }
        }
      }]);

      return ProfilePage;
    }();

    ProfilePage.ctorParameters = function () {
      return [{
        type: _services_ionic_toast_service__WEBPACK_IMPORTED_MODULE_9__["IonicToastService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _services_fcm_service__WEBPACK_IMPORTED_MODULE_8__["FcmService"]
      }, {
        type: _savedcards_service__WEBPACK_IMPORTED_MODULE_5__["SavedcardsService"]
      }, {
        type: _profile_profile_service__WEBPACK_IMPORTED_MODULE_7__["SendingService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }];
    };

    ProfilePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-profile',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./profile.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/profile/profile.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./profile.page.scss */
      "./src/app/savedcards/profile/profile.page.scss"))["default"]]
    })], ProfilePage);
    /***/
  }
}]);
//# sourceMappingURL=profile-profile-module-es5.js.map