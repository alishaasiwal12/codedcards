(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["savedcards-savedcards-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/savedcards.page.html":
/*!***************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/savedcards.page.html ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-tabs>\n  <ion-tab-bar slot=\"bottom\">\n    <ion-tab-button tab=\"profile\">\n      <ion-label>Account</ion-label>\n      <ion-icon name=\"person\"></ion-icon>\n    </ion-tab-button>\n    <ion-tab-button tab=\"mycards\">\n      <ion-label>Cards</ion-label>\n      <ion-icon name=\"card\"></ion-icon>\n    </ion-tab-button>\n    <ion-tab-button tab=\"sharedcards\">\n      <ion-label>Shared</ion-label>\n      <ion-icon name=\"list\"></ion-icon>\n    </ion-tab-button>\n  </ion-tab-bar>\n</ion-tabs>\n");

/***/ }),

/***/ "./src/app/savedcards/savedcards-routing.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/savedcards/savedcards-routing.module.ts ***!
  \*********************************************************/
/*! exports provided: SavedcardsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavedcardsPageRoutingModule", function() { return SavedcardsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _savedcards_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./savedcards.page */ "./src/app/savedcards/savedcards.page.ts");




const routes = [
    {
        path: 'tabs',
        component: _savedcards_page__WEBPACK_IMPORTED_MODULE_3__["SavedcardsPage"],
        children: [
            {
                path: 'profile',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | profile-profile-module */[__webpack_require__.e("default~profile-profile-module~profile-userdetails-userdetails-module"), __webpack_require__.e("common"), __webpack_require__.e("profile-profile-module")]).then(__webpack_require__.bind(null, /*! ./profile/profile.module */ "./src/app/savedcards/profile/profile.module.ts")).then(m => m.ProfilePageModule)
                    },
                    {
                        path: ':userId',
                        loadChildren: () => Promise.all(/*! import() | profile-userdetails-userdetails-module */[__webpack_require__.e("default~profile-profile-module~profile-userdetails-userdetails-module"), __webpack_require__.e("profile-userdetails-userdetails-module")]).then(__webpack_require__.bind(null, /*! ./profile/userdetails/userdetails.module */ "./src/app/savedcards/profile/userdetails/userdetails.module.ts")).then(m => m.UserdetailsPageModule)
                    },
                    {
                        path: 'edit/:userId',
                        loadChildren: () => __webpack_require__.e(/*! import() | profile-edit-user-edit-user-module */ "profile-edit-user-edit-user-module").then(__webpack_require__.bind(null, /*! ./profile/edit-user/edit-user.module */ "./src/app/savedcards/profile/edit-user/edit-user.module.ts")).then(m => m.EditUserPageModule)
                    }
                ]
            },
            {
                path: 'mycards',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | mycards-mycards-module */[__webpack_require__.e("common"), __webpack_require__.e("mycards-mycards-module")]).then(__webpack_require__.bind(null, /*! ./mycards/mycards.module */ "./src/app/savedcards/mycards/mycards.module.ts")).then(m => m.MycardsPageModule)
                    }
                ]
            },
            {
                path: 'sharedcards',
                children: [
                    {
                        path: '',
                        loadChildren: () => Promise.all(/*! import() | sharedcards-sharedcards-module */[__webpack_require__.e("common"), __webpack_require__.e("sharedcards-sharedcards-module")]).then(__webpack_require__.bind(null, /*! ./sharedcards/sharedcards.module */ "./src/app/savedcards/sharedcards/sharedcards.module.ts")).then(m => m.SharedcardsPageModule)
                    }
                ]
            },
            {
                path: '',
                redirectTo: '/savedcards/tabs/mycards',
                pathMatch: 'full'
            }
        ]
    },
    {
        path: '',
        redirectTo: '/savedcards/tabs/mycards',
        pathMatch: 'full'
    }
];
let SavedcardsPageRoutingModule = class SavedcardsPageRoutingModule {
};
SavedcardsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], SavedcardsPageRoutingModule);



/***/ }),

/***/ "./src/app/savedcards/savedcards.module.ts":
/*!*************************************************!*\
  !*** ./src/app/savedcards/savedcards.module.ts ***!
  \*************************************************/
/*! exports provided: SavedcardsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavedcardsPageModule", function() { return SavedcardsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _savedcards_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./savedcards-routing.module */ "./src/app/savedcards/savedcards-routing.module.ts");
/* harmony import */ var _savedcards_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./savedcards.page */ "./src/app/savedcards/savedcards.page.ts");







let SavedcardsPageModule = class SavedcardsPageModule {
};
SavedcardsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _savedcards_routing_module__WEBPACK_IMPORTED_MODULE_5__["SavedcardsPageRoutingModule"]
        ],
        declarations: [_savedcards_page__WEBPACK_IMPORTED_MODULE_6__["SavedcardsPage"]]
    })
], SavedcardsPageModule);



/***/ }),

/***/ "./src/app/savedcards/savedcards.page.scss":
/*!*************************************************!*\
  !*** ./src/app/savedcards/savedcards.page.scss ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NhdmVkY2FyZHMvc2F2ZWRjYXJkcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/savedcards/savedcards.page.ts":
/*!***********************************************!*\
  !*** ./src/app/savedcards/savedcards.page.ts ***!
  \***********************************************/
/*! exports provided: SavedcardsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavedcardsPage", function() { return SavedcardsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let SavedcardsPage = class SavedcardsPage {
    constructor() { }
    ngOnInit() {
    }
};
SavedcardsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-savedcards',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./savedcards.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/savedcards.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./savedcards.page.scss */ "./src/app/savedcards/savedcards.page.scss")).default]
    })
], SavedcardsPage);



/***/ })

}]);
//# sourceMappingURL=savedcards-savedcards-module-es2015.js.map