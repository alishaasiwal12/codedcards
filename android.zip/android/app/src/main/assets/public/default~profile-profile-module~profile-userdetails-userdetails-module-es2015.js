(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~profile-profile-module~profile-userdetails-userdetails-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/pickers/image-picker/image-picker.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shared/pickers/image-picker/image-picker.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div class=\"picker\">\n  <ion-img\n    role=\"button\"\n    class=\"image\"\n    (click)=\"onPickImage()\"\n    [src]=\"selectedImage\"\n    *ngIf=\"selectedImage && showPreview\"\n  ></ion-img>\n  <ion-button color=\"primary\" (click)=\"onPickImage()\" *ngIf=\"!selectedImage || !showPreview\">\n    <ion-icon name=\"camera\" slot=\"start\"></ion-icon>\n    <ion-label>Take Picture</ion-label>\n  </ion-button>\n</div>\n<input\n  type=\"file\"\n  accept=\"image/jpeg\"\n  *ngIf=\"usePicker\"\n  #filePicker\n  (change)=\"onFileChosen($event)\"\n/>\n");

/***/ }),

/***/ "./src/app/savedcards/savedcards.model.ts":
/*!************************************************!*\
  !*** ./src/app/savedcards/savedcards.model.ts ***!
  \************************************************/
/*! exports provided: Savedcard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Savedcard", function() { return Savedcard; });
class Savedcard {
    constructor(id, customertype, name, designation, contactnumber, companyname, companytagline, companywebsite, officeaddress, userId, userEmail, imageUrl) {
        this.id = id;
        this.customertype = customertype;
        this.name = name;
        this.designation = designation;
        this.contactnumber = contactnumber;
        this.companyname = companyname;
        this.companytagline = companytagline;
        this.companywebsite = companywebsite;
        this.officeaddress = officeaddress;
        this.userId = userId;
        this.userEmail = userEmail;
        this.imageUrl = imageUrl;
    }
}


/***/ }),

/***/ "./src/app/savedcards/savedcards.service.ts":
/*!**************************************************!*\
  !*** ./src/app/savedcards/savedcards.service.ts ***!
  \**************************************************/
/*! exports provided: SavedcardsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SavedcardsService", function() { return SavedcardsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _savedcards_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./savedcards.model */ "./src/app/savedcards/savedcards.model.ts");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../auth/auth.service */ "./src/app/auth/auth.service.ts");







let SavedcardsService = class SavedcardsService {
    constructor(authService, http) {
        this.authService = authService;
        this.http = http;
        this._cards = new rxjs__WEBPACK_IMPORTED_MODULE_3__["BehaviorSubject"]([]);
    }
    get savedcards() {
        return this._cards.asObservable();
    }
    addUser(customertype, name, designation, contactnumber, companyname, companytagline, companywebsite, officeaddress, fetchedUserEmail, imageUrl) {
        let generatedId;
        let fetchedUserId;
        let newSavedcard;
        return this.authService.userId.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(userId => {
            fetchedUserId = userId;
            return this.authService.token;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(token => {
            if (!fetchedUserId) {
                throw new Error('No user found!');
            }
            newSavedcard = new _savedcards_model__WEBPACK_IMPORTED_MODULE_5__["Savedcard"](Math.random().toString(), customertype, name, designation, contactnumber, companyname, companytagline, companywebsite, officeaddress, fetchedUserId, fetchedUserEmail, imageUrl);
            return this.http.post(`https://codedcards.firebaseio.com/customers.json?auth=${token}`, Object.assign(Object.assign({}, newSavedcard), { id: null }), {
                headers: new _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpHeaders"]({
                    "Content-Type": "application/json"
                })
            });
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(resData => {
            generatedId = resData.name;
            return this.savedcards;
        }));
    }
    getMyAccount(fetchedUserEmail) {
        let fetchedUserId;
        return this.authService.token.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(userId => {
            fetchedUserId = userId;
            return this.authService.token;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(token => {
            return this.http.get(`https://codedcards.firebaseio.com/customers.json?auth=${token}`);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(savedcardData => {
            if (savedcardData != null || savedcardData != undefined) {
                for (var key in savedcardData) {
                    if (!savedcardData.hasOwnProperty(key))
                        continue;
                    var output = savedcardData[key].userEmail;
                    if (output == fetchedUserEmail) {
                        var response = savedcardData[key];
                        return new _savedcards_model__WEBPACK_IMPORTED_MODULE_5__["Savedcard"](fetchedUserEmail, response.customertype, response.name, response.designation, response.contactnumber, response.companyname, response.companytagline, response.companywebsite, response.officeaddress, response.userId, response.userEmail, response.imageUrl);
                    }
                }
            }
            else {
                return null;
            }
        }));
    }
    getReceiver(receiverContactNumber) {
        let fetchedUserEmail;
        return this.authService.token.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(email => {
            fetchedUserEmail = email;
            return this.authService.token;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["switchMap"])(token => {
            return this.http.get(`https://codedcards.firebaseio.com/customers.json?auth=${token}`);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["map"])(savedcardData => {
            if (savedcardData != null || savedcardData != undefined) {
                for (var key in savedcardData) {
                    if (!savedcardData.hasOwnProperty(key))
                        continue;
                    var output = savedcardData[key].contactnumber;
                    if (output == receiverContactNumber) {
                        var response = savedcardData[key];
                        return new _savedcards_model__WEBPACK_IMPORTED_MODULE_5__["Savedcard"](fetchedUserEmail, response.customertype, response.name, response.designation, response.contactnumber, response.companyname, response.companytagline, response.companywebsite, response.officeaddress, response.userId, response.userEmail, response.imageUrl);
                    }
                }
            }
            else {
                return null;
            }
        }));
    }
};
SavedcardsService.ctorParameters = () => [
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"] },
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
SavedcardsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], SavedcardsService);



/***/ }),

/***/ "./src/app/shared/pickers/image-picker/image-picker.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/shared/pickers/image-picker/image-picker.component.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".picker {\n  width: 30rem;\n  max-width: 80%;\n  height: 20rem;\n  max-height: 30vh;\n  border: 1px solid var(--ion-color-primary);\n  margin: auto;\n  display: flex;\n  justify-content: center;\n  align-items: center;\n}\n\n.image {\n  width: 100%;\n  height: 100%;\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n\ninput[type=file] {\n  display: none;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hhcmVkL3BpY2tlcnMvaW1hZ2UtcGlja2VyL0U6XFxBbGlzaGFcXFdvcmtcXHZzY29kZVxcY29kZWRjYXJkcy9zcmNcXGFwcFxcc2hhcmVkXFxwaWNrZXJzXFxpbWFnZS1waWNrZXJcXGltYWdlLXBpY2tlci5jb21wb25lbnQuc2NzcyIsInNyYy9hcHAvc2hhcmVkL3BpY2tlcnMvaW1hZ2UtcGlja2VyL2ltYWdlLXBpY2tlci5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsMENBQUE7RUFDQSxZQUFBO0VBQ0EsYUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUNDSjs7QURFRTtFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0Esb0JBQUE7S0FBQSxpQkFBQTtBQ0NKOztBREVFO0VBQ0UsYUFBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvc2hhcmVkL3BpY2tlcnMvaW1hZ2UtcGlja2VyL2ltYWdlLXBpY2tlci5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5waWNrZXIge1xyXG4gICAgd2lkdGg6IDMwcmVtO1xyXG4gICAgbWF4LXdpZHRoOiA4MCU7XHJcbiAgICBoZWlnaHQ6IDIwcmVtO1xyXG4gICAgbWF4LWhlaWdodDogMzB2aDtcclxuICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcclxuICAgIG1hcmdpbjogYXV0bztcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgfVxyXG4gIFxyXG4gIC5pbWFnZSB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIGhlaWdodDogMTAwJTtcclxuICAgIG9iamVjdC1maXQ6IGNvdmVyO1xyXG4gIH1cclxuICBcclxuICBpbnB1dFt0eXBlPSdmaWxlJ10ge1xyXG4gICAgZGlzcGxheTogbm9uZTtcclxuICB9XHJcbiAgIiwiLnBpY2tlciB7XG4gIHdpZHRoOiAzMHJlbTtcbiAgbWF4LXdpZHRoOiA4MCU7XG4gIGhlaWdodDogMjByZW07XG4gIG1heC1oZWlnaHQ6IDMwdmg7XG4gIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KTtcbiAgbWFyZ2luOiBhdXRvO1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cblxuLmltYWdlIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGhlaWdodDogMTAwJTtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG5cbmlucHV0W3R5cGU9ZmlsZV0ge1xuICBkaXNwbGF5OiBub25lO1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/shared/pickers/image-picker/image-picker.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/shared/pickers/image-picker/image-picker.component.ts ***!
  \***********************************************************************/
/*! exports provided: ImagePickerComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ImagePickerComponent", function() { return ImagePickerComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let ImagePickerComponent = class ImagePickerComponent {
    constructor(platform) {
        this.platform = platform;
        this.imagePick = new _angular_core__WEBPACK_IMPORTED_MODULE_1__["EventEmitter"]();
        this.showPreview = false;
        this.usePicker = false;
    }
    ngOnInit() {
        console.log('Mobile:', this.platform.is('mobile'));
        console.log('Hybrid:', this.platform.is('hybrid'));
        console.log('iOS:', this.platform.is('ios'));
        console.log('Android:', this.platform.is('android'));
        console.log('Desktop:', this.platform.is('desktop'));
        if ((this.platform.is('mobile') && !this.platform.is('hybrid')) ||
            this.platform.is('desktop')) {
            this.usePicker = true;
        }
    }
    onPickImage() {
        if (!_capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Capacitor"].isPluginAvailable('Camera')) {
            this.filePickerRef.nativeElement.click();
            return;
        }
        _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"].Camera.getPhoto({
            quality: 50,
            source: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["CameraSource"].Prompt,
            correctOrientation: true,
            // height: 320,
            width: 300,
            resultType: _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["CameraResultType"].Base64
        })
            .then(image => {
            this.selectedImage = image.base64String;
            this.imagePick.emit(image.base64String);
        })
            .catch(error => {
            console.log(error);
            if (this.usePicker) {
                this.filePickerRef.nativeElement.click();
            }
            return false;
        });
    }
    onFileChosen(event) {
        const pickedFile = event.target.files[0];
        if (!pickedFile) {
            return;
        }
        const fr = new FileReader();
        fr.onload = () => {
            const dataUrl = fr.result.toString();
            this.selectedImage = dataUrl;
            this.imagePick.emit(pickedFile);
        };
        fr.readAsDataURL(pickedFile);
    }
};
ImagePickerComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('filePicker', { static: false })
], ImagePickerComponent.prototype, "filePickerRef", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Output"])()
], ImagePickerComponent.prototype, "imagePick", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ImagePickerComponent.prototype, "showPreview", void 0);
ImagePickerComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-image-picker',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./image-picker.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/shared/pickers/image-picker/image-picker.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./image-picker.component.scss */ "./src/app/shared/pickers/image-picker/image-picker.component.scss")).default]
    })
], ImagePickerComponent);



/***/ }),

/***/ "./src/app/shared/shared.module.ts":
/*!*****************************************!*\
  !*** ./src/app/shared/shared.module.ts ***!
  \*****************************************/
/*! exports provided: SharedModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedModule", function() { return SharedModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _pickers_image_picker_image_picker_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./pickers/image-picker/image-picker.component */ "./src/app/shared/pickers/image-picker/image-picker.component.ts");






let SharedModule = class SharedModule {
};
SharedModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [
            _pickers_image_picker_image_picker_component__WEBPACK_IMPORTED_MODULE_5__["ImagePickerComponent"]
        ],
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"]],
        exports: [_pickers_image_picker_image_picker_component__WEBPACK_IMPORTED_MODULE_5__["ImagePickerComponent"]]
    })
], SharedModule);



/***/ })

}]);
//# sourceMappingURL=default~profile-profile-module~profile-userdetails-userdetails-module-es2015.js.map