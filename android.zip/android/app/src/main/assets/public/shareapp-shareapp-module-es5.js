function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["shareapp-shareapp-module"], {
  /***/
  "./node_modules/@ionic-native/social-sharing/index.js":
  /*!************************************************************!*\
    !*** ./node_modules/@ionic-native/social-sharing/index.js ***!
    \************************************************************/

  /*! exports provided: SocialSharing */

  /***/
  function node_modulesIonicNativeSocialSharingIndexJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SocialSharing", function () {
      return SocialSharing;
    });
    /* harmony import */


    var _ionic_native_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! @ionic-native/core */
    "./node_modules/@ionic-native/core/__ivy_ngcc__/index.js");

    var __extends = undefined && undefined.__extends || function () {
      var _extendStatics = function extendStatics(d, b) {
        _extendStatics = Object.setPrototypeOf || {
          __proto__: []
        } instanceof Array && function (d, b) {
          d.__proto__ = b;
        } || function (d, b) {
          for (var p in b) {
            if (b.hasOwnProperty(p)) d[p] = b[p];
          }
        };

        return _extendStatics(d, b);
      };

      return function (d, b) {
        _extendStatics(d, b);

        function __() {
          this.constructor = d;
        }

        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
      };
    }();

    var SocialSharingOriginal =
    /** @class */
    function (_super) {
      __extends(SocialSharingOriginal, _super);

      function SocialSharingOriginal() {
        return _super !== null && _super.apply(this, arguments) || this;
      }

      SocialSharingOriginal.prototype.share = function (message, subject, file, url) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "share", {
          "successIndex": 4,
          "errorIndex": 5
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareWithOptions = function (options) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareWithOptions", {
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.canShareVia = function (appName, message, subject, image, url) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "canShareVia", {
          "successIndex": 5,
          "errorIndex": 6,
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareViaTwitter = function (message, image, url) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareViaTwitter", {
          "successIndex": 3,
          "errorIndex": 4,
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareViaFacebook = function (message, image, url) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareViaFacebook", {
          "successIndex": 3,
          "errorIndex": 4,
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareViaFacebookWithPasteMessageHint = function (message, image, url, pasteMessageHint) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareViaFacebookWithPasteMessageHint", {
          "successIndex": 4,
          "errorIndex": 5,
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareViaInstagram = function (message, image) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareViaInstagram", {
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareViaWhatsApp = function (message, image, url) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareViaWhatsApp", {
          "successIndex": 3,
          "errorIndex": 4,
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareViaWhatsAppToReceiver = function (receiver, message, image, url) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareViaWhatsAppToReceiver", {
          "successIndex": 4,
          "errorIndex": 5,
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareViaSMS = function (messge, phoneNumber) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareViaSMS", {
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.canShareViaEmail = function () {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "canShareViaEmail", {
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareViaEmail = function (message, subject, to, cc, bcc, files) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareViaEmail", {
          "platforms": ["iOS", "Android"],
          "successIndex": 6,
          "errorIndex": 7
        }, arguments);
      };

      SocialSharingOriginal.prototype.shareVia = function (appName, message, subject, image, url) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "shareVia", {
          "successIndex": 5,
          "errorIndex": 6,
          "platforms": ["iOS", "Android"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.setIPadPopupCoordinates = function (targetBounds) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "setIPadPopupCoordinates", {
          "sync": true,
          "platforms": ["iOS"]
        }, arguments);
      };

      SocialSharingOriginal.prototype.saveToPhotoAlbum = function (fileOrFileArray) {
        return Object(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["cordova"])(this, "saveToPhotoAlbum", {
          "platforms": ["iOS"]
        }, arguments);
      };

      SocialSharingOriginal.pluginName = "SocialSharing";
      SocialSharingOriginal.plugin = "cordova-plugin-x-socialsharing";
      SocialSharingOriginal.pluginRef = "plugins.socialsharing";
      SocialSharingOriginal.repo = "https://github.com/EddyVerbruggen/SocialSharing-PhoneGap-Plugin";
      SocialSharingOriginal.platforms = ["Android", "Browser", "iOS", "Windows", "Windows Phone"];
      return SocialSharingOriginal;
    }(_ionic_native_core__WEBPACK_IMPORTED_MODULE_0__["IonicNativePlugin"]);

    var SocialSharing = new SocialSharingOriginal(); //# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvQGlvbmljLW5hdGl2ZS9wbHVnaW5zL3NvY2lhbC1zaGFyaW5nL2luZGV4LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFDQSxPQUFPLDhCQUFzQyxNQUFNLG9CQUFvQixDQUFDOztJQXlDckMsaUNBQWlCOzs7O0lBYWxELDZCQUFLLGFBQUMsT0FBZ0IsRUFBRSxPQUFnQixFQUFFLElBQXdCLEVBQUUsR0FBWTtJQVloRix3Q0FBZ0IsYUFBQyxPQU1oQjtJQWtCRCxtQ0FBVyxhQUFDLE9BQWUsRUFBRSxPQUFnQixFQUFFLE9BQWdCLEVBQUUsS0FBYyxFQUFFLEdBQVk7SUFnQjdGLHVDQUFlLGFBQUMsT0FBZSxFQUFFLEtBQWMsRUFBRSxHQUFZO0lBZ0I3RCx3Q0FBZ0IsYUFBQyxPQUFlLEVBQUUsS0FBYyxFQUFFLEdBQVk7SUFpQjlELDREQUFvQyxhQUNsQyxPQUFlLEVBQ2YsS0FBYyxFQUNkLEdBQVksRUFDWixnQkFBeUI7SUFjM0IseUNBQWlCLGFBQUMsT0FBZSxFQUFFLEtBQWE7SUFnQmhELHdDQUFnQixhQUFDLE9BQWUsRUFBRSxLQUFjLEVBQUUsR0FBWTtJQWlCOUQsa0RBQTBCLGFBQUMsUUFBZ0IsRUFBRSxPQUFlLEVBQUUsS0FBYyxFQUFFLEdBQVk7SUFhMUYsbUNBQVcsYUFBQyxNQUFjLEVBQUUsV0FBbUI7SUFXL0Msd0NBQWdCO0lBbUJoQixxQ0FBYSxhQUNYLE9BQWUsRUFDZixPQUFlLEVBQ2YsRUFBWSxFQUNaLEVBQWEsRUFDYixHQUFjLEVBQ2QsS0FBeUI7SUFtQjNCLGdDQUFRLGFBQUMsT0FBZSxFQUFFLE9BQWUsRUFBRSxPQUFnQixFQUFFLEtBQWMsRUFBRSxHQUFZO0lBWXpGLCtDQUF1QixhQUFDLFlBQW9CO0lBVTVDLHdDQUFnQixhQUFDLGVBQWtDOzs7Ozs7d0JBelJyRDtFQTBDbUMsaUJBQWlCO1NBQXZDLGFBQWEiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBJbmplY3RhYmxlIH0gZnJvbSAnQGFuZ3VsYXIvY29yZSc7XG5pbXBvcnQgeyBDb3Jkb3ZhLCBJb25pY05hdGl2ZVBsdWdpbiwgUGx1Z2luIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9jb3JlJztcblxuLyoqXG4gKiBAbmFtZSBTb2NpYWwgU2hhcmluZ1xuICogQHByZW1pZXIgc29jaWFsLXNoYXJpbmdcbiAqIEBkZXNjcmlwdGlvblxuICogU2hhcmUgdGV4dCwgZmlsZXMsIGltYWdlcywgYW5kIGxpbmtzIHZpYSBzb2NpYWwgbmV0d29ya3MsIHNtcywgYW5kIGVtYWlsLlxuICpcbiAqIEZvciBCcm93c2VyIHVzYWdlIGNoZWNrIG91dCB0aGUgV2ViIFNoYXJlIEFQSSBkb2NzOiBodHRwczovL2dpdGh1Yi5jb20vRWRkeVZlcmJydWdnZW4vU29jaWFsU2hhcmluZy1QaG9uZUdhcC1QbHVnaW4jNS13ZWItc2hhcmUtYXBpXG4gKlxuICogQHVzYWdlXG4gKiBgYGB0eXBlc2NyaXB0XG4gKiBpbXBvcnQgeyBTb2NpYWxTaGFyaW5nIH0gZnJvbSAnQGlvbmljLW5hdGl2ZS9zb2NpYWwtc2hhcmluZy9uZ3gnO1xuICpcbiAqIGNvbnN0cnVjdG9yKHByaXZhdGUgc29jaWFsU2hhcmluZzogU29jaWFsU2hhcmluZykgeyB9XG4gKlxuICogLi4uXG4gKlxuICogLy8gQ2hlY2sgaWYgc2hhcmluZyB2aWEgZW1haWwgaXMgc3VwcG9ydGVkXG4gKiB0aGlzLnNvY2lhbFNoYXJpbmcuY2FuU2hhcmVWaWFFbWFpbCgpLnRoZW4oKCkgPT4ge1xuICogICAvLyBTaGFyaW5nIHZpYSBlbWFpbCBpcyBwb3NzaWJsZVxuICogfSkuY2F0Y2goKCkgPT4ge1xuICogICAvLyBTaGFyaW5nIHZpYSBlbWFpbCBpcyBub3QgcG9zc2libGVcbiAqIH0pO1xuICpcbiAqIC8vIFNoYXJlIHZpYSBlbWFpbFxuICogdGhpcy5zb2NpYWxTaGFyaW5nLnNoYXJlVmlhRW1haWwoJ0JvZHknLCAnU3ViamVjdCcsIFsncmVjaXBpZW50QGV4YW1wbGUub3JnJ10pLnRoZW4oKCkgPT4ge1xuICogICAvLyBTdWNjZXNzIVxuICogfSkuY2F0Y2goKCkgPT4ge1xuICogICAvLyBFcnJvciFcbiAqIH0pO1xuICogYGBgXG4gKi9cbkBQbHVnaW4oe1xuICBwbHVnaW5OYW1lOiAnU29jaWFsU2hhcmluZycsXG4gIHBsdWdpbjogJ2NvcmRvdmEtcGx1Z2luLXgtc29jaWFsc2hhcmluZycsXG4gIHBsdWdpblJlZjogJ3BsdWdpbnMuc29jaWFsc2hhcmluZycsXG4gIHJlcG86ICdodHRwczovL2dpdGh1Yi5jb20vRWRkeVZlcmJydWdnZW4vU29jaWFsU2hhcmluZy1QaG9uZUdhcC1QbHVnaW4nLFxuICBwbGF0Zm9ybXM6IFsnQW5kcm9pZCcsICdCcm93c2VyJywgJ2lPUycsICdXaW5kb3dzJywgJ1dpbmRvd3MgUGhvbmUnXSxcbn0pXG5ASW5qZWN0YWJsZSgpXG5leHBvcnQgY2xhc3MgU29jaWFsU2hhcmluZyBleHRlbmRzIElvbmljTmF0aXZlUGx1Z2luIHtcbiAgLyoqXG4gICAqIFNoYXJlcyB1c2luZyB0aGUgc2hhcmUgc2hlZXRcbiAgICogQHBhcmFtIG1lc3NhZ2Uge3N0cmluZ30gVGhlIG1lc3NhZ2UgeW91IHdvdWxkIGxpa2UgdG8gc2hhcmUuXG4gICAqIEBwYXJhbSBzdWJqZWN0IHtzdHJpbmd9IFRoZSBzdWJqZWN0XG4gICAqIEBwYXJhbSBmaWxlIHtzdHJpbmd8c3RyaW5nW119IFVSTChzKSB0byBmaWxlKHMpIG9yIGltYWdlKHMpLCBsb2NhbCBwYXRoKHMpIHRvIGZpbGUocykgb3IgaW1hZ2UocyksIG9yIGJhc2U2NCBkYXRhIG9mIGFuIGltYWdlLiBPbmx5IHRoZSBmaXJzdCBmaWxlL2ltYWdlIHdpbGwgYmUgdXNlZCBvbiBXaW5kb3dzIFBob25lLlxuICAgKiBAcGFyYW0gdXJsIHtzdHJpbmd9IEEgVVJMIHRvIHNoYXJlXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgc3VjY2Vzc0luZGV4OiA0LFxuICAgIGVycm9ySW5kZXg6IDUsXG4gIH0pXG4gIHNoYXJlKG1lc3NhZ2U/OiBzdHJpbmcsIHN1YmplY3Q/OiBzdHJpbmcsIGZpbGU/OiBzdHJpbmcgfCBzdHJpbmdbXSwgdXJsPzogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogU2hhcmVzIHVzaW5nIHRoZSBzaGFyZSBzaGVldCB3aXRoIGFkZGl0aW9uYWwgb3B0aW9ucyBhbmQgcmV0dXJucyBhIHJlc3VsdCBvYmplY3Qgb3IgYW4gZXJyb3IgbWVzc2FnZSAocmVxdWlyZXMgcGx1Z2luIHZlcnNpb24gNS4xLjArKVxuICAgKiBAcGFyYW0gb3B0aW9ucyB7b2JqZWN0fSBUaGUgb3B0aW9ucyBvYmplY3Qgd2l0aCB0aGUgbWVzc2FnZSwgc3ViamVjdCwgZmlsZXMsIHVybCBhbmQgY2hvb3NlclRpdGxlIHByb3BlcnRpZXMuXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgcGxhdGZvcm1zOiBbJ2lPUycsICdBbmRyb2lkJ10sXG4gIH0pXG4gIHNoYXJlV2l0aE9wdGlvbnMob3B0aW9uczoge1xuICAgIG1lc3NhZ2U/OiBzdHJpbmc7XG4gICAgc3ViamVjdD86IHN0cmluZztcbiAgICBmaWxlcz86IHN0cmluZyB8IHN0cmluZ1tdO1xuICAgIHVybD86IHN0cmluZztcbiAgICBjaG9vc2VyVGl0bGU/OiBzdHJpbmc7XG4gIH0pOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVja3MgaWYgeW91IGNhbiBzaGFyZSB2aWEgYSBzcGVjaWZpYyBhcHAuXG4gICAqIEBwYXJhbSBhcHBOYW1lIHtzdHJpbmd9IEFwcCBuYW1lIG9yIHBhY2thZ2UgbmFtZS4gRXhhbXBsZXM6IGluc3RhZ3JhbSBvciBjb20uYXBwbGUuc29jaWFsLmZhY2Vib29rXG4gICAqIEBwYXJhbSBtZXNzYWdlIHtzdHJpbmd9XG4gICAqIEBwYXJhbSBzdWJqZWN0IHtzdHJpbmd9XG4gICAqIEBwYXJhbSBpbWFnZSB7c3RyaW5nfVxuICAgKiBAcGFyYW0gdXJsIHtzdHJpbmd9XG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgc3VjY2Vzc0luZGV4OiA1LFxuICAgIGVycm9ySW5kZXg6IDYsXG4gICAgcGxhdGZvcm1zOiBbJ2lPUycsICdBbmRyb2lkJ10sXG4gIH0pXG4gIGNhblNoYXJlVmlhKGFwcE5hbWU6IHN0cmluZywgbWVzc2FnZT86IHN0cmluZywgc3ViamVjdD86IHN0cmluZywgaW1hZ2U/OiBzdHJpbmcsIHVybD86IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFNoYXJlcyBkaXJlY3RseSB0byBUd2l0dGVyXG4gICAqIEBwYXJhbSBtZXNzYWdlIHtzdHJpbmd9XG4gICAqIEBwYXJhbSBpbWFnZSB7c3RyaW5nfVxuICAgKiBAcGFyYW0gdXJsIHtzdHJpbmd9XG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgc3VjY2Vzc0luZGV4OiAzLFxuICAgIGVycm9ySW5kZXg6IDQsXG4gICAgcGxhdGZvcm1zOiBbJ2lPUycsICdBbmRyb2lkJ10sXG4gIH0pXG4gIHNoYXJlVmlhVHdpdHRlcihtZXNzYWdlOiBzdHJpbmcsIGltYWdlPzogc3RyaW5nLCB1cmw/OiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBTaGFyZXMgZGlyZWN0bHkgdG8gRmFjZWJvb2tcbiAgICogQHBhcmFtIG1lc3NhZ2Uge3N0cmluZ31cbiAgICogQHBhcmFtIGltYWdlIHtzdHJpbmd9XG4gICAqIEBwYXJhbSB1cmwge3N0cmluZ31cbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBzdWNjZXNzSW5kZXg6IDMsXG4gICAgZXJyb3JJbmRleDogNCxcbiAgICBwbGF0Zm9ybXM6IFsnaU9TJywgJ0FuZHJvaWQnXSxcbiAgfSlcbiAgc2hhcmVWaWFGYWNlYm9vayhtZXNzYWdlOiBzdHJpbmcsIGltYWdlPzogc3RyaW5nLCB1cmw/OiBzdHJpbmcpOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxuXG4gIC8qKlxuICAgKiBTaGFyZXMgZGlyZWN0bHkgdG8gRmFjZWJvb2sgd2l0aCBhIHBhc3RlIG1lc3NhZ2UgaGludFxuICAgKiBAcGFyYW0gbWVzc2FnZSB7c3RyaW5nfVxuICAgKiBAcGFyYW0gaW1hZ2Uge3N0cmluZ31cbiAgICogQHBhcmFtIHVybCB7c3RyaW5nfVxuICAgKiBAcGFyYW0gcGFzdGVNZXNzYWdlSGludCB7c3RyaW5nfVxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHN1Y2Nlc3NJbmRleDogNCxcbiAgICBlcnJvckluZGV4OiA1LFxuICAgIHBsYXRmb3JtczogWydpT1MnLCAnQW5kcm9pZCddLFxuICB9KVxuICBzaGFyZVZpYUZhY2Vib29rV2l0aFBhc3RlTWVzc2FnZUhpbnQoXG4gICAgbWVzc2FnZTogc3RyaW5nLFxuICAgIGltYWdlPzogc3RyaW5nLFxuICAgIHVybD86IHN0cmluZyxcbiAgICBwYXN0ZU1lc3NhZ2VIaW50Pzogc3RyaW5nXG4gICk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFNoYXJlcyBkaXJlY3RseSB0byBJbnN0YWdyYW1cbiAgICogQHBhcmFtIG1lc3NhZ2Uge3N0cmluZ31cbiAgICogQHBhcmFtIGltYWdlIHtzdHJpbmd9XG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgcGxhdGZvcm1zOiBbJ2lPUycsICdBbmRyb2lkJ10sXG4gIH0pXG4gIHNoYXJlVmlhSW5zdGFncmFtKG1lc3NhZ2U6IHN0cmluZywgaW1hZ2U6IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFNoYXJlcyBkaXJlY3RseSB0byBXaGF0c0FwcFxuICAgKiBAcGFyYW0gbWVzc2FnZSB7c3RyaW5nfVxuICAgKiBAcGFyYW0gaW1hZ2Uge3N0cmluZ31cbiAgICogQHBhcmFtIHVybCB7c3RyaW5nfVxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHN1Y2Nlc3NJbmRleDogMyxcbiAgICBlcnJvckluZGV4OiA0LFxuICAgIHBsYXRmb3JtczogWydpT1MnLCAnQW5kcm9pZCddLFxuICB9KVxuICBzaGFyZVZpYVdoYXRzQXBwKG1lc3NhZ2U6IHN0cmluZywgaW1hZ2U/OiBzdHJpbmcsIHVybD86IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFNoYXJlcyBkaXJlY3RseSB0byBhIFdoYXRzQXBwIENvbnRhY3RcbiAgICogQHBhcmFtIHJlY2VpdmVyIHtzdHJpbmd9IFBhc3MgcGhvbmUgbnVtYmVyIG9uIEFuZHJvaWQsIGFuZCBBZGRyZXNzYm9vayBJRCAoYWJpZCkgb24gaU9TXG4gICAqIEBwYXJhbSBtZXNzYWdlIHtzdHJpbmd9IE1lc3NhZ2UgdG8gc2VuZFxuICAgKiBAcGFyYW0gaW1hZ2Uge3N0cmluZ30gSW1hZ2UgdG8gc2VuZCAoZG9lcyBub3Qgd29yayBvbiBpT1NcbiAgICogQHBhcmFtIHVybCB7c3RyaW5nfSBMaW5rIHRvIHNlbmRcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55Pn1cbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBzdWNjZXNzSW5kZXg6IDQsXG4gICAgZXJyb3JJbmRleDogNSxcbiAgICBwbGF0Zm9ybXM6IFsnaU9TJywgJ0FuZHJvaWQnXSxcbiAgfSlcbiAgc2hhcmVWaWFXaGF0c0FwcFRvUmVjZWl2ZXIocmVjZWl2ZXI6IHN0cmluZywgbWVzc2FnZTogc3RyaW5nLCBpbWFnZT86IHN0cmluZywgdXJsPzogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogU2hhcmUgdmlhIFNNU1xuICAgKiBAcGFyYW0gbWVzc2dlIHtzdHJpbmd9IG1lc3NhZ2UgdG8gc2VuZFxuICAgKiBAcGFyYW0gcGhvbmVOdW1iZXIge3N0cmluZ30gTnVtYmVyIG9yIG11bHRpcGxlIG51bWJlcnMgc2VwZXJhdGVkIGJ5IGNvbW1hc1xuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHBsYXRmb3JtczogWydpT1MnLCAnQW5kcm9pZCddLFxuICB9KVxuICBzaGFyZVZpYVNNUyhtZXNzZ2U6IHN0cmluZywgcGhvbmVOdW1iZXI6IHN0cmluZyk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrcyBpZiB5b3UgY2FuIHNoYXJlIHZpYSBlbWFpbFxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxhbnk+fVxuICAgKi9cbiAgQENvcmRvdmEoe1xuICAgIHBsYXRmb3JtczogWydpT1MnLCAnQW5kcm9pZCddLFxuICB9KVxuICBjYW5TaGFyZVZpYUVtYWlsKCk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFNoYXJlIHZpYSBFbWFpbFxuICAgKiBAcGFyYW0gbWVzc2FnZSB7c3RyaW5nfVxuICAgKiBAcGFyYW0gc3ViamVjdCB7c3RyaW5nfVxuICAgKiBAcGFyYW0gdG8ge3N0cmluZ1tdfVxuICAgKiBAcGFyYW0gY2Mge3N0cmluZ1tdfSBPcHRpb25hbFxuICAgKiBAcGFyYW0gYmNjIHtzdHJpbmdbXX0gT3B0aW9uYWxcbiAgICogQHBhcmFtIGZpbGVzIHtzdHJpbmd8c3RyaW5nW119IE9wdGlvbmFsIFVSTCBvciBsb2NhbCBwYXRoIHRvIGZpbGUocykgdG8gYXR0YWNoXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgcGxhdGZvcm1zOiBbJ2lPUycsICdBbmRyb2lkJ10sXG4gICAgc3VjY2Vzc0luZGV4OiA2LFxuICAgIGVycm9ySW5kZXg6IDcsXG4gIH0pXG4gIHNoYXJlVmlhRW1haWwoXG4gICAgbWVzc2FnZTogc3RyaW5nLFxuICAgIHN1YmplY3Q6IHN0cmluZyxcbiAgICB0bzogc3RyaW5nW10sXG4gICAgY2M/OiBzdHJpbmdbXSxcbiAgICBiY2M/OiBzdHJpbmdbXSxcbiAgICBmaWxlcz86IHN0cmluZyB8IHN0cmluZ1tdXG4gICk6IFByb21pc2U8YW55PiB7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLyoqXG4gICAqIFNoYXJlIHZpYSBBcHBOYW1lXG4gICAqIEBwYXJhbSBhcHBOYW1lIHtzdHJpbmd9IEFwcCBuYW1lIG9yIHBhY2thZ2UgbmFtZS4gRXhhbXBsZXM6IGluc3RhZ3JhbSBvciBjb20uYXBwbGUuc29jaWFsLmZhY2Vib29rXG4gICAqIEBwYXJhbSBtZXNzYWdlIHtzdHJpbmd9XG4gICAqIEBwYXJhbSBzdWJqZWN0IHtzdHJpbmd9XG4gICAqIEBwYXJhbSBpbWFnZSB7c3RyaW5nfVxuICAgKiBAcGFyYW0gdXJsIHtzdHJpbmd9XG4gICAqIEByZXR1cm5zIHtQcm9taXNlPGFueT59XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgc3VjY2Vzc0luZGV4OiA1LFxuICAgIGVycm9ySW5kZXg6IDYsXG4gICAgcGxhdGZvcm1zOiBbJ2lPUycsICdBbmRyb2lkJ10sXG4gIH0pXG4gIHNoYXJlVmlhKGFwcE5hbWU6IHN0cmluZywgbWVzc2FnZTogc3RyaW5nLCBzdWJqZWN0Pzogc3RyaW5nLCBpbWFnZT86IHN0cmluZywgdXJsPzogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICByZXR1cm47XG4gIH1cblxuICAvKipcbiAgICogZGVmaW5lcyB0aGUgcG9wdXAgcG9zaXRpb24gYmVmb3JlIGNhbGwgdGhlIHNoYXJlIG1ldGhvZC5cbiAgICogQHBhcmFtIHRhcmdldEJvdW5kcyB7c3RyaW5nfSBsZWZ0LCB0b3AsIHdpZHRoLCBoZWlnaHRcbiAgICovXG4gIEBDb3Jkb3ZhKHtcbiAgICBzeW5jOiB0cnVlLFxuICAgIHBsYXRmb3JtczogWydpT1MnXSxcbiAgfSlcbiAgc2V0SVBhZFBvcHVwQ29vcmRpbmF0ZXModGFyZ2V0Qm91bmRzOiBzdHJpbmcpOiB2b2lkIHt9XG5cbiAgLyoqXG4gICAqIFNhdmUgYW4gYXJyYXkgb2YgaW1hZ2VzIHRvIHRoZSBjYW1lcmEgcm9sbFxuICAgKiBAcGFyYW0gIHtzdHJpbmd8c3RyaW5nW119IGZpbGVPckZpbGVBcnJheSBTaW5nbGUgb3IgbXVsdGlwbGUgZmlsZXNcbiAgICogQHJldHVybnMge1Byb21pc2U8YW55PiB9XG4gICAqL1xuICBAQ29yZG92YSh7XG4gICAgcGxhdGZvcm1zOiBbJ2lPUyddLFxuICB9KVxuICBzYXZlVG9QaG90b0FsYnVtKGZpbGVPckZpbGVBcnJheTogc3RyaW5nIHwgc3RyaW5nW10pOiBQcm9taXNlPGFueT4ge1xuICAgIHJldHVybjtcbiAgfVxufVxuIl19

    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/shareapp/shareapp.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/shareapp/shareapp.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppShareappShareappPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Share App</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">\n  <p>Share</p>\n  <!-- <button default (click)=\"sharePicker()\">Share</button> -->\n\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/shareapp/shareapp-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/shareapp/shareapp-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: ShareappPageRoutingModule */

  /***/
  function srcAppShareappShareappRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ShareappPageRoutingModule", function () {
      return ShareappPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _shareapp_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./shareapp.page */
    "./src/app/shareapp/shareapp.page.ts");

    var routes = [{
      path: '',
      component: _shareapp_page__WEBPACK_IMPORTED_MODULE_3__["ShareappPage"]
    }];

    var ShareappPageRoutingModule = function ShareappPageRoutingModule() {
      _classCallCheck(this, ShareappPageRoutingModule);
    };

    ShareappPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ShareappPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/shareapp/shareapp.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/shareapp/shareapp.module.ts ***!
    \*********************************************/

  /*! exports provided: ShareappPageModule */

  /***/
  function srcAppShareappShareappModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ShareappPageModule", function () {
      return ShareappPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _shareapp_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./shareapp-routing.module */
    "./src/app/shareapp/shareapp-routing.module.ts");
    /* harmony import */


    var _shareapp_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./shareapp.page */
    "./src/app/shareapp/shareapp.page.ts");

    var ShareappPageModule = function ShareappPageModule() {
      _classCallCheck(this, ShareappPageModule);
    };

    ShareappPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _shareapp_routing_module__WEBPACK_IMPORTED_MODULE_5__["ShareappPageRoutingModule"]],
      declarations: [_shareapp_page__WEBPACK_IMPORTED_MODULE_6__["ShareappPage"]]
    })], ShareappPageModule);
    /***/
  },

  /***/
  "./src/app/shareapp/shareapp.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/shareapp/shareapp.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppShareappShareappPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NoYXJlYXBwL3NoYXJlYXBwLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/shareapp/shareapp.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/shareapp/shareapp.page.ts ***!
    \*******************************************/

  /*! exports provided: ShareappPage */

  /***/
  function srcAppShareappShareappPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ShareappPage", function () {
      return ShareappPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _ionic_native_social_sharing__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic-native/social-sharing */
    "./node_modules/@ionic-native/social-sharing/index.js");

    var ShareappPage = /*#__PURE__*/function () {
      function ShareappPage(navCtrl, platform) {
        _classCallCheck(this, ShareappPage);

        this.navCtrl = navCtrl;
        this.platform = platform;
        this.subject = 'Message from Coded Cards App';
        this.message = 'Download this business cards application: Coded Cards - ';
        this.image = 'http://masteringionic2.com/perch/resources/mastering-ionic-2-cover-1-w320.png';
        this.uri = 'https://drive.google.com/file/d/14LQ93sD1T65T8DQzkIb1hQ3sDE5RxAPb/view?usp=sharing';
      }

      _createClass(ShareappPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.sharePicker();
        }
      }, {
        key: "shareViaEmail",
        value: function shareViaEmail() {
          var _this = this;

          this.platform.ready().then(function () {
            _ionic_native_social_sharing__WEBPACK_IMPORTED_MODULE_3__["SocialSharing"].canShareViaEmail().then(function () {
              _ionic_native_social_sharing__WEBPACK_IMPORTED_MODULE_3__["SocialSharing"].shareViaEmail(_this.message, _this.subject, _this.sendTo).then(function (data) {
                console.log('Shared via Email');
              })["catch"](function (err) {
                console.log('Not able to be shared via Email');
              });
            })["catch"](function (err) {
              console.log('Sharing via Email NOT enabled');
            });
          });
        }
      }, {
        key: "shareViaFacebook",
        value: function shareViaFacebook() {
          var _this2 = this;

          this.platform.ready().then(function () {
            _ionic_native_social_sharing__WEBPACK_IMPORTED_MODULE_3__["SocialSharing"].canShareVia('com.apple.social.facebook', _this2.message, _this2.image, _this2.uri).then(function (data) {
              _ionic_native_social_sharing__WEBPACK_IMPORTED_MODULE_3__["SocialSharing"].shareViaFacebook(_this2.message, _this2.image, _this2.uri).then(function (data) {
                console.log('Shared via Facebook');
              })["catch"](function (err) {
                console.log('Was not shared via Facebook');
              });
            })["catch"](function (err) {
              console.log('Not able to be shared via Facebook');
            });
          });
        }
      }, {
        key: "shareViaInstagram",
        value: function shareViaInstagram() {
          var _this3 = this;

          this.platform.ready().then(function () {
            _ionic_native_social_sharing__WEBPACK_IMPORTED_MODULE_3__["SocialSharing"].shareViaInstagram(_this3.message, _this3.image).then(function (data) {
              console.log('Shared via shareViaInstagram');
            })["catch"](function (err) {
              console.log('Was not shared via Instagram');
            });
          });
        }
      }, {
        key: "shareViaTwitter",
        value: function shareViaTwitter() {
          var _this4 = this;

          this.platform.ready().then(function () {
            _ionic_native_social_sharing__WEBPACK_IMPORTED_MODULE_3__["SocialSharing"].canShareVia('com.apple.social.twitter', _this4.message, _this4.image, _this4.uri).then(function (data) {
              _ionic_native_social_sharing__WEBPACK_IMPORTED_MODULE_3__["SocialSharing"].shareViaTwitter(_this4.message, _this4.image, _this4.uri).then(function (data) {
                console.log('Shared via Twitter');
              })["catch"](function (err) {
                console.log('Was not shared via Twitter');
              });
            });
          })["catch"](function (err) {
            console.log('Not able to be shared via Twitter');
          });
        }
      }, {
        key: "sharePicker",
        value: function sharePicker() {
          var _this5 = this;

          this.platform.ready().then(function () {
            _ionic_native_social_sharing__WEBPACK_IMPORTED_MODULE_3__["SocialSharing"].share(_this5.message, _this5.subject, _this5.image, _this5.uri).then(function (data) {
              console.log('Shared via SharePicker');
            })["catch"](function (err) {
              console.log('Was not shared via SharePicker');
            });
          });
        }
      }]);

      return ShareappPage;
    }();

    ShareappPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"]
      }];
    };

    ShareappPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-shareapp',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./shareapp.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/shareapp/shareapp.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./shareapp.page.scss */
      "./src/app/shareapp/shareapp.page.scss"))["default"]]
    })], ShareappPage);
    /***/
  }
}]);
//# sourceMappingURL=shareapp-shareapp-module-es5.js.map