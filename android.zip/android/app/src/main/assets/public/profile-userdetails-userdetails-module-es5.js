function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-userdetails-userdetails-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/profile/userdetails/userdetails.page.html":
  /*!************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/profile/userdetails/userdetails.page.html ***!
    \************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppSavedcardsProfileUserdetailsUserdetailsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button defaultHref=\"/savedcards/tabs/profile\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>User Registration</ion-title>\n    <ion-buttons slot=\"primary\">\n      <!-- <ion-button (click)=\"onCreateUser()\" [disabled]=\"!form.valid || !form.get('image').value\"> -->\n      <ion-button (click)=\"onCreateUser()\">\n        <ion-icon name=\"checkmark\" slot=\"icon-only\"></ion-icon>\n      </ion-button>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <form [formGroup]=\"form\">\n    <ion-grid>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-list>\n            <ion-radio-group allow-empty-selection=\"true\" (ionChange)=\"customerTypeHandler($event)\"\n              (ionSelect)=\"goCustomerType($event)\" (ionBlur)=\"leaveCustomerType($event)\" formControlName=\"customertype\">\n              <ion-list-header>\n                <ion-label>User Type</ion-label>\n              </ion-list-header>\n\n              <ion-item>\n                <ion-label>Corporate</ion-label>\n                <ion-radio slot=\"start\" value=\"corporate\" checked></ion-radio>\n              </ion-item>\n              <ion-item>\n                <ion-label>Individual</ion-label>\n                <ion-radio slot=\"start\" value=\"individual\"></ion-radio>\n              </ion-item>\n\n            </ion-radio-group>\n          </ion-list>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\">Name</ion-label>\n            <ion-input type=\"text\" autocomplete autocorrect formControlName=\"name\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\">Designation</ion-label>\n            <ion-input type=\"text\" formControlName=\"designation\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\">Contact Number</ion-label>\n            <ion-input type=\"number\" formControlName=\"contactnumber\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <ion-row *ngIf=\"\n          !form.get('contactnumber').valid && form.get('contactnumber').touched\">\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <p>Contact Number must have 10 numbers.</p>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\">Company Name</ion-label>\n            <ion-input type=\"text\" formControlName=\"companyname\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\">Company Tagline</ion-label>\n            <ion-input type=\"text\" formControlName=\"companytagline\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\">Company Website</ion-label>\n            <ion-input type=\"text\" formControlName=\"companywebsite\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n      <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-item>\n            <ion-label position=\"floating\">Office Address</ion-label>\n            <ion-input type=\"text\" formControlName=\"officeaddress\"></ion-input>\n          </ion-item>\n        </ion-col>\n      </ion-row>\n       <ion-row>\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\n          <ion-card class=\"ion-text-center\" *ngIf=\"!isUploading && !isUploaded\">\n            <ion-item>\n              <ion-label>Upload Card?</ion-label>\n              <ion-toggle default=\"\" color=\"success\" (ionChange)=\"hide($event)\">\n              </ion-toggle>\n            </ion-item>\n            <ion-card-content>\n              <ion-button color=\"light\" [disabled]=\"disabled\">\n                <input id=\"uploadBtn\" type=\"file\" class=\"upload\" (change)=\"uploadFile($event.target.files)\" />\n              </ion-button>\n            </ion-card-content>\n          </ion-card>\n\n          <ion-card class=\"ion-text-center\" *ngIf=\"isUploading && !isUploaded\">\n            <ion-card-header>\n              <ion-card-title>Selected File:<b>{{ fileName }}</b></ion-card-title>\n            </ion-card-header>\n        \n            <ion-card-content>\n              <div *ngIf=\"percentage | async as pct\">\n                Progress: {{ pct | number }}%\n                <ion-progress-bar value=\"{{ pct / 100 }}\"></ion-progress-bar>\n              </div>\n              <div *ngIf=\"snapshot | async as snap\">\n                File Size: {{ snap.totalBytes | fileSizePipe }} Transfered:\n                {{ snap.bytesTransferred | fileSizePipe }}\n              </div>\n            </ion-card-content>\n          </ion-card>\n          \n          <ion-card class=\"ion-text-center\" *ngIf=\"!isUploading && isUploaded\">\n            <ion-card-header>\n              <ion-card-title>\n                <b>{{ fileName }}</b> Uploaded!\n              </ion-card-title>\n            </ion-card-header>\n        \n            <ion-card-content>\n              <div *ngIf=\"UploadedFileURL | async as url\">\n                <img [src]=\"url\" />\n                <a [href]=\"url\" target=\"_blank\" rel=\"noopener\">Download</a>\n              </div>\n              File Size: {{ fileSize | fileSizePipe }}\n              <ion-button expand=\"full\" color=\"success\" (click)=\"isUploading = isUploaded = false\">Upload More</ion-button>\n            </ion-card-content>\n          </ion-card>\n\n        </ion-col>\n      </ion-row> \n    </ion-grid>\n  </form>\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/savedcards/profile/userdetails/file-size-format.pipe.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/savedcards/profile/userdetails/file-size-format.pipe.ts ***!
    \*************************************************************************/

  /*! exports provided: FileSizeFormatPipe */

  /***/
  function srcAppSavedcardsProfileUserdetailsFileSizeFormatPipeTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FileSizeFormatPipe", function () {
      return FileSizeFormatPipe;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js"); //file-size-format.pipe.ts


    var FILE_SIZE_UNITS = ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    var FILE_SIZE_UNITS_LONG = ['Bytes', 'Kilobytes', 'Megabytes', 'Gigabytes', 'Pettabytes', 'Exabytes', 'Zettabytes', 'Yottabytes'];

    var FileSizeFormatPipe = /*#__PURE__*/function () {
      function FileSizeFormatPipe() {
        _classCallCheck(this, FileSizeFormatPipe);
      }

      _createClass(FileSizeFormatPipe, [{
        key: "transform",
        value: function transform(sizeInBytes, longForm) {
          var units = longForm ? FILE_SIZE_UNITS_LONG : FILE_SIZE_UNITS;
          var power = Math.round(Math.log(sizeInBytes) / Math.log(1024));
          power = Math.min(power, units.length - 1);
          var size = sizeInBytes / Math.pow(1024, power); // size in new units

          var formattedSize = Math.round(size * 100) / 100; // keep up to 2 decimals

          var unit = units[power];
          return "".concat(formattedSize, " ").concat(unit);
        }
      }], [{
        key: "forRoot",
        value: function forRoot() {
          throw new Error("Method not implemented.");
        }
      }]);

      return FileSizeFormatPipe;
    }();

    FileSizeFormatPipe = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'fileSizePipe'
    })], FileSizeFormatPipe);
    /***/
  },

  /***/
  "./src/app/savedcards/profile/userdetails/userdetails.module.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/savedcards/profile/userdetails/userdetails.module.ts ***!
    \**********************************************************************/

  /*! exports provided: UserdetailsPageModule */

  /***/
  function srcAppSavedcardsProfileUserdetailsUserdetailsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserdetailsPageModule", function () {
      return UserdetailsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _userdetails_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./userdetails.page */
    "./src/app/savedcards/profile/userdetails/userdetails.page.ts");
    /* harmony import */


    var _file_size_format_pipe__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./file-size-format.pipe */
    "./src/app/savedcards/profile/userdetails/file-size-format.pipe.ts");
    /* harmony import */


    var _shared_shared_module__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../../../shared/shared.module */
    "./src/app/shared/shared.module.ts");

    var routes = [{
      path: '',
      component: _userdetails_page__WEBPACK_IMPORTED_MODULE_6__["UserdetailsPage"]
    }];

    var UserdetailsPageModule = function UserdetailsPageModule() {
      _classCallCheck(this, UserdetailsPageModule);
    };

    UserdetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes), _shared_shared_module__WEBPACK_IMPORTED_MODULE_8__["SharedModule"]],
      declarations: [_userdetails_page__WEBPACK_IMPORTED_MODULE_6__["UserdetailsPage"], _file_size_format_pipe__WEBPACK_IMPORTED_MODULE_7__["FileSizeFormatPipe"]]
    })], UserdetailsPageModule);
    /***/
  },

  /***/
  "./src/app/savedcards/profile/userdetails/userdetails.page.scss":
  /*!**********************************************************************!*\
    !*** ./src/app/savedcards/profile/userdetails/userdetails.page.scss ***!
    \**********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppSavedcardsProfileUserdetailsUserdetailsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NhdmVkY2FyZHMvcHJvZmlsZS91c2VyZGV0YWlscy91c2VyZGV0YWlscy5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/savedcards/profile/userdetails/userdetails.page.ts":
  /*!********************************************************************!*\
    !*** ./src/app/savedcards/profile/userdetails/userdetails.page.ts ***!
    \********************************************************************/

  /*! exports provided: UserdetailsPage */

  /***/
  function srcAppSavedcardsProfileUserdetailsUserdetailsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UserdetailsPage", function () {
      return UserdetailsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _savedcards_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../savedcards.service */
    "./src/app/savedcards/savedcards.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _angular_fire_storage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/fire/storage */
    "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-storage.js");
    /* harmony import */


    var _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/fire/firestore */
    "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-firestore.js");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../../../auth/auth.service */
    "./src/app/auth/auth.service.ts");
    /* harmony import */


    var _services_ionic_toast_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ../../../services/ionic-toast.service */
    "./src/app/services/ionic-toast.service.ts");

    var UserdetailsPage = /*#__PURE__*/function () {
      function UserdetailsPage(SavedcardsService, router, loadingCtrl, storage, database, authService, ionicToastService, toastController) {
        _classCallCheck(this, UserdetailsPage);

        this.SavedcardsService = SavedcardsService;
        this.router = router;
        this.loadingCtrl = loadingCtrl;
        this.storage = storage;
        this.database = database;
        this.authService = authService;
        this.ionicToastService = ionicToastService;
        this.toastController = toastController;
        this.disabled = true;
        this.isUploading = false;
        this.isUploaded = false; //Set collection where our documents/ images info will save

        this.imageCollection = database.collection('userCardImages');
        this.images = this.imageCollection.valueChanges();
      }

      _createClass(UserdetailsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.form = new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormGroup"]({
            customertype: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
              updateOn: 'blur',
              validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            }),
            name: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
              updateOn: 'blur',
              validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            }),
            designation: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
              updateOn: 'blur',
              validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            }),
            contactnumber: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
              updateOn: 'blur',
              validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required, _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].maxLength(10)]
            }),
            companyname: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
              updateOn: 'blur',
              validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            }),
            companytagline: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
              updateOn: 'blur',
              validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            }),
            companywebsite: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
              updateOn: 'blur',
              validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            }),
            officeaddress: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null, {
              updateOn: 'blur',
              validators: [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]
            }),
            image: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"](null)
          });
        }
      }, {
        key: "customerTypeHandler",
        value: function customerTypeHandler(event) {
          // get data throught event emitter
          this.customertype = event.target.value;
        }
      }, {
        key: "leaveCustomerType",
        value: function leaveCustomerType(event) {
          console.log('bye bye ', event.target.value);
        }
      }, {
        key: "goCustomerType",
        value: function goCustomerType(event) {
          console.log('hello ', event.target.value);
        }
      }, {
        key: "hide",
        value: function hide(e) {
          this.disabled = !this.disabled;
        }
      }, {
        key: "uploadFile",
        value: function uploadFile(event) {
          var _this = this;

          // The File object
          var file = event.item(0); // Validation for Images Only

          if (file.type.split('/')[0] !== 'image') {
            console.error('unsupported file type :( ');
            return;
          }

          this.isUploading = true;
          this.isUploaded = false;
          this.fileName = file.name; // The storage path

          var path = "userCardsStorage/".concat(file.name, "_").concat(this.form.get('name').value, "_").concat(this.form.get('contactnumber').value); // Totally optional metadata

          var customMetadata = {
            app: 'User Cards Image Upload'
          }; //File reference

          var fileRef = this.storage.ref(path); // The main task

          this.task = this.storage.upload(path, file, {
            customMetadata: customMetadata
          }); // Get file progress percentage

          this.percentage = this.task.percentageChanges();
          this.snapshot = this.task.snapshotChanges().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["finalize"])(function () {
            // Get uploaded file storage path
            _this.UploadedFileURL = fileRef.getDownloadURL();

            _this.UploadedFileURL.subscribe(function (resp) {
              _this.addImagetoDB({
                filename: file.name,
                filepath: resp,
                size: _this.fileSize
              });

              _this.isUploading = false;
              _this.isUploaded = true;
            }, function (error) {
              console.error(error);
            });
          }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["tap"])(function (snap) {
            _this.fileSize = snap.totalBytes;
          }));
        }
      }, {
        key: "addImagetoDB",
        value: function addImagetoDB(image) {
          var _this2 = this;

          //Create an ID for document
          var id = this.database.createId(); //Set document id with value in database

          this.imageCollection.doc(id).set(image).then(function (resp) {
            _this2.imageUrl = image.filepath;
          })["catch"](function (error) {
            console.log("error " + error);
          });
        }
      }, {
        key: "onCreateUser",
        value: function onCreateUser() {
          var _this3 = this;

          // if (!this.form.valid || !this.form.get('image').value) {
          // if (!this.form.valid) {
          //   return;
          // }
          this.loadingCtrl.create({
            message: 'Creating Business Card...'
          }).then(function (loadingEl) {
            loadingEl.present();
            var fetchedUserEmail;

            _this3.authService.userEmail.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["take"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_6__["switchMap"])(function (userEmail) {
              fetchedUserEmail = userEmail;
              return _this3.SavedcardsService.addUser(_this3.customertype, _this3.form.value.name, _this3.form.value.designation, _this3.form.value.contactnumber, _this3.form.value.companyname, _this3.form.value.companytagline, _this3.form.value.companywebsite, _this3.form.value.officeaddress, fetchedUserEmail, _this3.imageUrl);
            })).subscribe(function () {
              loadingEl.dismiss();

              _this3.form.reset();

              _this3.router.navigate(['/savedcards/tabs/profile']);
            });
          });
          this.ionicToastService.cardCreatedToast();
          this.ionicToastService.HideToast();
        }
      }]);

      return UserdetailsPage;
    }();

    UserdetailsPage.ctorParameters = function () {
      return [{
        type: _savedcards_service__WEBPACK_IMPORTED_MODULE_5__["SavedcardsService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }, {
        type: _angular_fire_storage__WEBPACK_IMPORTED_MODULE_7__["AngularFireStorage"]
      }, {
        type: _angular_fire_firestore__WEBPACK_IMPORTED_MODULE_8__["AngularFirestore"]
      }, {
        type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_9__["AuthService"]
      }, {
        type: _services_ionic_toast_service__WEBPACK_IMPORTED_MODULE_10__["IonicToastService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
      }];
    };

    UserdetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-userdetails',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./userdetails.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/profile/userdetails/userdetails.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./userdetails.page.scss */
      "./src/app/savedcards/profile/userdetails/userdetails.page.scss"))["default"]]
    })], UserdetailsPage);
    /***/
  }
}]);
//# sourceMappingURL=profile-userdetails-userdetails-module-es5.js.map