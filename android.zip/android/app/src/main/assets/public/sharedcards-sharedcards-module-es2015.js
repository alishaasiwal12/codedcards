(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["sharedcards-sharedcards-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/sharedcards/sharedcards.page.html":
/*!****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/sharedcards/sharedcards.page.html ***!
  \****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>Shared Cards</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <ion-grid>\n    <ion-row>\n      <ion-col size-md=\"6\" offset-md=\"3\" class=\"ion-text-center\" *ngIf=\"isLoading\">\n        <ion-spinner color=\"primary\"></ion-spinner>\n      </ion-col>\n      <ion-col size-md=\"6\" offset-md=\"3\" *ngIf=\"!isLoading && (!loadedNetworks || loadedNetworks.length <= 0)\"\n        class=\"ion-text-center\">\n        <p>No Business Cards Shared!</p>\n      </ion-col>\n      <ion-col size-md=\"6\" offset-md=\"3\" *ngIf=\"!isLoading && loadedNetworks && loadedNetworks.length > 0\">\n        <ion-list>\n          <ion-item-sliding *ngFor=\"let network of loadedNetworks\" #slidingSending>\n            <ion-item>\n              <!-- <ion-avatar slot=\"start\">\n                <ion-img [src]=\"network.senderCardImage\"></ion-img> \n              </ion-avatar> -->\n               <ion-avatar item-start>\n                <ion-text-avatar color=\"secondary\">CC</ion-text-avatar>\n              </ion-avatar> \n              <ion-label>\n                <h5>{{ network.receiverName }}</h5>\n                <p>Company: {{ network.receiverCompanyName }}</p>\n                <p>Contact Number: {{ network.receiverContactNumber }}</p>\n              </ion-label>\n            </ion-item>\n            <ion-item-options>\n              <ion-item-option color=\"danger\" (click)=\"onCancelSending(network.id, slidingSending)\">\n                <ion-icon name=\"trash\" slot=\"icon-only\"></ion-icon>\n              </ion-item-option>\n            </ion-item-options>\n          </ion-item-sliding>\n        </ion-list>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>");

/***/ }),

/***/ "./src/app/savedcards/sharedcards/sharedcards.module.ts":
/*!**************************************************************!*\
  !*** ./src/app/savedcards/sharedcards/sharedcards.module.ts ***!
  \**************************************************************/
/*! exports provided: SharedcardsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedcardsPageModule", function() { return SharedcardsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _sharedcards_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./sharedcards.page */ "./src/app/savedcards/sharedcards/sharedcards.page.ts");







const routes = [
    {
        path: '',
        component: _sharedcards_page__WEBPACK_IMPORTED_MODULE_6__["SharedcardsPage"]
    }
];
let SharedcardsPageModule = class SharedcardsPageModule {
};
SharedcardsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_sharedcards_page__WEBPACK_IMPORTED_MODULE_6__["SharedcardsPage"]]
    })
], SharedcardsPageModule);



/***/ }),

/***/ "./src/app/savedcards/sharedcards/sharedcards.page.scss":
/*!**************************************************************!*\
  !*** ./src/app/savedcards/sharedcards/sharedcards.page.scss ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NhdmVkY2FyZHMvc2hhcmVkY2FyZHMvc2hhcmVkY2FyZHMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/savedcards/sharedcards/sharedcards.page.ts":
/*!************************************************************!*\
  !*** ./src/app/savedcards/sharedcards/sharedcards.page.ts ***!
  \************************************************************/
/*! exports provided: SharedcardsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SharedcardsPage", function() { return SharedcardsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _profile_profile_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../profile/profile.service */ "./src/app/savedcards/profile/profile.service.ts");




let SharedcardsPage = class SharedcardsPage {
    constructor(sendingService, loadingCtrl) {
        this.sendingService = sendingService;
        this.loadingCtrl = loadingCtrl;
        this.isLoading = false;
    }
    ngOnInit() {
        this.sendingSub = this.sendingService.sendings.subscribe(sendings => {
            this.loadedNetworks = sendings;
        });
    }
    ionViewWillEnter() {
        this.isLoading = true;
        this.sendingService.fetchSharedcards().subscribe(() => {
            this.isLoading = false;
        });
    }
    onCancelSending(receiverId, slidingEl) {
        slidingEl.close();
        this.loadingCtrl.create({ message: 'Cancelling...' }).then(loadingEl => {
            loadingEl.present();
            this.sendingService.cancelSending(receiverId).subscribe(() => {
                loadingEl.dismiss();
            });
        });
    }
    ngOnDestroy() {
        if (this.sendingSub) {
            this.sendingSub.unsubscribe();
        }
    }
};
SharedcardsPage.ctorParameters = () => [
    { type: _profile_profile_service__WEBPACK_IMPORTED_MODULE_3__["SendingService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
SharedcardsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-sharedcards',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./sharedcards.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/savedcards/sharedcards/sharedcards.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./sharedcards.page.scss */ "./src/app/savedcards/sharedcards/sharedcards.page.scss")).default]
    })
], SharedcardsPage);



/***/ })

}]);
//# sourceMappingURL=sharedcards-sharedcards-module-es2015.js.map